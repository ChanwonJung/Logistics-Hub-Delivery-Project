__dsr__id = ""
__dsr__model = ""
__dsr__node = None