^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package dsr_common2
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.1 (2024-12-17)
------------------
* Fixes robot mode inconsistency (https://github.com/doosan-robotics/doosan-robot2/issues/122)


1.1.0 (2021-07-01)
------------------
* update changelog
* update drfl.lib to GL010110
* launch drcf-emulator automatically
* update emulator
* update moveit package
* ROS2 Alpha
* for newest ros2_control package
* ROS2 Alpha
* Update package.xml
* ROS2 Alpha
* ROS2 Alpha
* Contributors: doosan robotics ros master, doosan-robotics, dra

* update drfl.lib to GL010110
* launch drcf-emulator automatically
* update emulator
* update moveit package
* ROS2 Alpha
* for newest ros2_control package
* ROS2 Alpha
* Update package.xml
* ROS2 Alpha
* ROS2 Alpha
* Contributors: doosan robotics ros master, doosan-robotics, dra

* Update package.xml
* ROS2 Alpha
* ROS2 Alpha
* Contributors: doosan robotics ros master, doosan-robotics

0.1.1 (2020-10-29)
------------------
* Update package.xml
* ROS2 Alpha
* Contributors: doosan robotics ros master, doosan-robotics
