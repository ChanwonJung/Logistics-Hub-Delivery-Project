^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package serial_node_example
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.9.8 (2019-06-18)
------------------

0.9.7 (2019-06-17)
------------------
* add serial example node in the service pack
* Contributors: doosan-robotics
